# SR Linux YANG models

This branch contains the source `.yang` files for Nokia SR Linux Network OS release .

Check the readme file in the [`main`](https://github.com/nokia/srlinux-yang-models/blob/main/README.md) branch for details on how to navigate this repo.
